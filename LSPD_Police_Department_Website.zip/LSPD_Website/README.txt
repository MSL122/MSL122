LSPD Roster Website
Open index.html in a browser to preview.
The roster supports search, rank filtering, adding officers, printing, responsive layout, and local browser storage.
For a public URL, upload this folder to a static host such as GitHub Pages, Netlify, or Cloudflare Pages.
